# QR Studio Chrome Extension

This converts the QR Studio website QR project into a Chrome Extension popup.

## Features
- Generate QR codes for website URLs
- Use the currently open tab's URL
- Download generated QR codes as PNG
- Copy the destination URL
- Keep up to 8 recent QR codes in Chrome's local extension storage
- Light/dark theme toggle
- No PHP server or database required

## Important QR service note
This build uses the external QR image API at `api.qrserver.com` to create QR images. The URL entered by the user is sent to that service to generate the QR image, so an internet connection is required. This is an image-generation API call, not remotely hosted executable code. Disclose this in the Chrome Web Store privacy/data-use fields. If you need QR generation fully offline, replace the API with a locally bundled QR encoder library before publishing.

## Install locally
1. Extract the ZIP.
2. Open Chrome and visit `chrome://extensions`.
3. Enable Developer mode.
4. Click **Load unpacked**.
5. Select the `extension` folder.
6. Pin QR Studio from the extensions menu for easy access.

## Publish
For Chrome Web Store submission, upload `QR_Studio_Chrome_Extension_Store_Package.zip`, whose root contains `manifest.json`, `popup.html`, `popup.js`, `style.css`, and `icons/`, after checking the privacy disclosures and store listing.
