const QR_API = "https://api.qrserver.com/v1/create-qr-code/";
const $ = (id) => document.getElementById(id);
let currentQrUrl = "";
let currentQrDataUrl = "";

document.addEventListener("DOMContentLoaded", async () => {
  const root = document.documentElement;
  const savedTheme = await chrome.storage.local.get("qrStudioTheme");
  if (savedTheme.qrStudioTheme === "dark") root.setAttribute("data-theme", "dark");
  updateThemeButton();

  $("themeToggle").addEventListener("click", async () => {
    const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next);
    await chrome.storage.local.set({ qrStudioTheme: next });
    updateThemeButton();
  });

  $("currentTab").addEventListener("click", async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && /^https?:\/\//i.test(tab.url)) {
        $("websiteUrl").value = tab.url;
        if (!$("title").value.trim()) $("title").value = new URL(tab.url).hostname;
        showMessage("Current tab URL added.", true);
      } else {
        showMessage("Chrome internal pages cannot be used as QR destinations.");
      }
    } catch {
      showMessage("Could not read the current tab. Enter the URL manually.");
    }
  });

  $("qrForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const title = $("title").value.trim().slice(0, 80);
    const websiteUrl = $("websiteUrl").value.trim();
    if (!title) return showMessage("Enter a project name.");
    let parsed;
    try { parsed = new URL(websiteUrl); } catch { return showMessage("Enter a valid website URL."); }
    if (!["http:", "https:"].includes(parsed.protocol) || !parsed.hostname.includes(".")) {
      return showMessage("Use a complete website URL beginning with http:// or https://.");
    }

    const button = $("generateButton");
    button.disabled = true;
    button.textContent = "Generating QR…";
    showMessage("");
    try {
      const apiUrl = new URL(QR_API);
      apiUrl.searchParams.set("size", "300x300");
      apiUrl.searchParams.set("format", "png");
      apiUrl.searchParams.set("data", websiteUrl);
      const response = await fetch(apiUrl.toString());
      if (!response.ok) throw new Error("QR service returned an error.");
      const blob = await response.blob();
      if (!blob.type.includes("image")) throw new Error("The QR service did not return an image.");
      currentQrDataUrl = await blobToDataUrl(blob);
      currentQrUrl = websiteUrl;
      $("qrImage").src = currentQrDataUrl;
      $("resultTitle").textContent = title;
      $("resultUrl").textContent = websiteUrl;
      $("qrResult").classList.remove("hidden");
      showMessage("QR code created successfully.", true);

      const entry = {
        id: crypto.randomUUID(),
        title,
        url: websiteUrl,
        image: currentQrDataUrl,
        createdAt: new Date().toISOString()
      };
      const data = await chrome.storage.local.get({ qrStudioHistory: [] });
      const history = [entry, ...data.qrStudioHistory.filter(item => item.url !== websiteUrl)].slice(0, 8);
      await chrome.storage.local.set({ qrStudioHistory: history });
      renderHistory(history);
    } catch (error) {
      showMessage("Could not generate the QR. Check your internet connection and try again.");
      console.error(error);
    } finally {
      button.disabled = false;
      button.innerHTML = 'Generate QR <span>↗</span>';
    }
  });

  $("downloadButton").addEventListener("click", () => {
    if (!currentQrDataUrl) return;
    downloadDataUrl(currentQrDataUrl, "qr-studio-website.png");
  });
  $("copyButton").addEventListener("click", async () => {
    if (!currentQrUrl) return;
    try {
      await navigator.clipboard.writeText(currentQrUrl);
      showMessage("Website URL copied to clipboard.", true);
    } catch {
      showMessage("Copy is unavailable. Select and copy the URL shown above.");
    }
  });
  $("clearHistory").addEventListener("click", async () => {
    await chrome.storage.local.set({ qrStudioHistory: [] });
    renderHistory([]);
  });
  $("clearButton").addEventListener("click", () => {
    $("qrResult").classList.add("hidden");
    showMessage("");
  });

  const data = await chrome.storage.local.get({ qrStudioHistory: [] });
  renderHistory(data.qrStudioHistory);
});

function updateThemeButton() {
  $("themeToggle").textContent = document.documentElement.getAttribute("data-theme") === "dark" ? "☼" : "◐";
}
function showMessage(text, success = false) {
  $("message").textContent = text;
  $("message").className = "message" + (success ? " success" : "");
}
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
function downloadDataUrl(dataUrl, filename) {
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
function renderHistory(history) {
  const list = $("historyList");
  list.replaceChildren();
  $("emptyHistory").classList.toggle("hidden", history.length > 0);
  history.forEach((item) => {
    const row = document.createElement("div");
    row.className = "history-item";
    const img = document.createElement("img");
    img.className = "history-thumb";
    img.src = item.image;
    img.alt = "";
    const info = document.createElement("div");
    info.className = "history-info";
    const title = document.createElement("strong");
    title.textContent = item.title;
    const url = document.createElement("span");
    url.textContent = item.url;
    info.append(title, url);
    const button = document.createElement("button");
    button.className = "history-download";
    button.textContent = "PNG ↓";
    button.type = "button";
    button.addEventListener("click", () => downloadDataUrl(item.image, "qr-studio-" + safeName(item.title) + ".png"));
    row.append(img, info, button);
    list.append(row);
  });
}
function safeName(value) {
  return String(value || "website").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "website";
}
